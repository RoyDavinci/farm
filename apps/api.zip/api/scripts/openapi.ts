import { regionInput } from '../src/services/regions.service.js';
import { voiceSignalInput } from '../src/services/voice.service.js';
import { parcelInput, parcelQuoteInput } from '../src/services/parcels.service.js';
import { returnJourneyInput } from '../src/services/returns-operations.service.js';
import { discoveryPreferenceInput } from '../src/services/discovery-operations.service.js';
import { tariffInput } from '../src/services/delivery-operations.service.js';
import { categoryInput, policyInput } from '../src/services/catalogue-policy.service.js';
import {
  sellerDetailsInput,
  driverDetailsInput,
  waypointInput,
  pathInput,
} from '../src/services/market-profiles.service.js';
import { boostInput } from '../src/services/status-boost.service.js';
import { statusAreaInput, publishStatusInput } from '../src/services/local-status.service.js';
import { nearbyRiderInput } from '../src/services/riders.service.js';
import { shoppingInput, shoppingQuoteInput } from '../src/services/shopping.service.js';
/**
 * Builds the OpenAPI 3.1 contract from the route files, controllers and zod validators.
 *   npm run openapi         write apps/api/openapi.json
 *   npm run openapi:check   fail if openapi.json is out of date (used in CI and tests)
 * Routes are read from source so the contract always lists exactly what the server mounts.
 */
import { readFileSync, readdirSync, writeFileSync } from 'node:fs';
import { dirname, join, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';
import { z } from 'zod';
import { responses } from '../src/contracts/index.js';
import { fundingInput } from '../src/validators/funding.validators.js';
import { searchInput } from '../src/validators/geography.validators.js';
import { listingSchema, sellerSchema } from '../src/validators/marketplace.validators.js';
import { resolveDisputeInput } from '../src/validators/support.validators.js';
import { checkoutInput } from '../src/services/checkout.service.js';
import {
  verificationApplyInput,
  verificationDecisionInput,
} from '../src/services/business-verification.service.js';
import {
  adInput,
  adPaymentInput,
  adStatusInput,
  featureShopInput,
  packageInput,
  partnerDriverInput,
  partnerInput,
  switchesInput,
} from '../src/services/revenue.service.js';
import {
  activateInput,
  importInput,
  listingAssistInput,
  planInput,
  quoteInput,
  rfqInput,
  subscribeInput,
  teamInput,
} from '../src/services/growth.service.js';
import { apiKeyInput, partnerListingInput, webhookInput } from '../src/services/partner.service.js';
import { planShareInput } from '../src/services/planner.service.js';
import { caseAssignInput, caseMessageInput, caseNoteInput } from '../src/services/cases.service.js';
import { allergenReportInput, allergenReviewInput } from '../src/services/planner-admin.service.js';
import { cartAddInput, cartCheckoutInput, cartUpdateInput } from '../src/services/cart.service.js';
import {
  dietProfileInput,
  planCreateInput,
  planItemInput,
  planItemUpdateInput,
  planMealInput,
  planReadInput,
  planUpdateInput,
} from '../src/services/planner.service.js';

const root = resolve(dirname(fileURLToPath(import.meta.url)), '..');
const src = join(root, 'src');
const read = (p: string) => readFileSync(join(src, p), 'utf8');

type Method = 'get' | 'post' | 'put' | 'patch' | 'delete';
interface Route {
  method: Method;
  path: string;
  tag: string;
  handler: string;
}

/** Prefix for each routes function, from routes/index.ts and app.ts. */
function mountPrefixes() {
  const index = read('routes/index.ts');
  const prefixes: Record<string, string> = { healthRoutes: '' };
  const section = (name: string) => {
    const start = index.indexOf(`export function ${name}`);
    return index.slice(start, index.indexOf('\n}\n', start));
  };
  for (const [fn, base] of [
    ['publicFileRoutes', ''],
    ['apiRoutes', '/v1'],
  ] as const) {
    for (const m of section(fn).matchAll(
      /r\.use\((?:'([^']+)',\s*)?(?:[\w.]+,\s*)*(\w+)\(deps\)\)/g,
    ))
      prefixes[m[2]] = `${base}${m[1] ?? ''}`;
  }
  return prefixes;
}

function routes(): Route[] {
  const prefixes = mountPrefixes();
  const out: Route[] = [];
  for (const file of readdirSync(join(src, 'routes')).filter((f) => f.endsWith('.routes.ts'))) {
    const text = read(`routes/${file}`);
    const tag = file.replace('.routes.ts', '');
    for (const fn of text.matchAll(/export function (\w+)\(deps: AppDeps\) \{([\s\S]*?)\n\}/g)) {
      const prefix = prefixes[fn[1]];
      if (prefix === undefined) throw new Error(`${fn[1]} is not mounted in routes/index.ts`);
      for (const r of fn[2].matchAll(
        /r\.(get|post|put|patch|delete)\('([^']*)',\s*(?:\.\.\.)?c\.(\w+)\)/g,
      )) {
        const path = `${prefix}${r[2] === '/' ? '' : r[2]}` || '/';
        out.push({ method: r[1] as Method, path, tag, handler: r[3] });
      }
    }
  }
  return out.sort((a, b) => a.path.localeCompare(b.path) || a.method.localeCompare(b.method));
}

/** Handlers that go through mutate() (or read the key themselves) need an Idempotency-Key. */
function idempotentHandlers() {
  const names = new Set<string>();
  for (const file of readdirSync(join(src, 'controllers'))) {
    const text = read(`controllers/${file}`);
    for (const m of text.matchAll(
      /const (\w+): RequestHandler(?:\[\])? = [\s\S]*?(?=\n  const \w+: RequestHandler|\n  return \{)/g,
    ))
      if (/mutate\(|readIdempotency\(|service\.startFunding\(|checkout\.startCheckout\(/.test(m[0]))
        names.add(`${file.replace('.controller.ts', '')}.${m[1]}`);
  }
  return names;
}

const isPublic = (r: Route) =>
  r.path.startsWith('/health') ||
  r.path.startsWith('/media') ||
  r.path.startsWith('/files') ||
  (r.path.startsWith('/v1/auth/') && r.handler !== 'logout') ||
  r.path.startsWith('/v1/webhooks/') ||
  r.path === '/v1/payments/return' ||
  r.path.startsWith('/v1/partner/') ||
  (r.path === '/v1/settings' && r.method === 'get');

const json = (schema: z.ZodType, io: 'input' | 'output' = 'input') =>
  z.toJSONSchema(schema, { io, unrepresentable: 'any' }) as Record<string, unknown>;
/** Request bodies (and query strings) with real schemas; others accept any JSON object. */
const bodies: Record<string, Record<string, unknown>> = {
  'wallet.startCheckout': json(checkoutInput),
  'cart.addToCart': json(cartAddInput),
  'planner.shareWith': json(planShareInput),
  'growth.subscribe': json(subscribeInput),
  'growth.createPlan': json(planInput),
  'growth.updatePlan': json(planInput),
  'growth.activateSubscription': json(activateInput),
  'growth.listingAssist': json(listingAssistInput),
  'growth.createRfq': json(rfqInput),
  'growth.submitQuote': json(quoteInput),
  'growth.addTeamMember': json(teamInput),
  'growth.importListings': json(importInput),
  'partner.createKey': json(apiKeyInput),
  'partner.createWebhook': json(webhookInput),
  'partner-api.updateListing': json(partnerListingInput),
  'business-verification.applyForVerification': json(verificationApplyInput),
  'business-verification.decideVerification': json(verificationDecisionInput),
  'revenue.saveSwitches': json(switchesInput),
  'revenue.savePackage': json(packageInput),
  'revenue.updatePackage': json(packageInput),
  'revenue.featureMyShop': json(featureShopInput),
  'revenue.saveAd': json(adInput),
  'revenue.updateAd': json(adInput),
  'revenue.setAdStatus': json(adStatusInput),
  'revenue.recordAdPayment': json(adPaymentInput),
  'revenue.savePartner': json(partnerInput),
  'revenue.updatePartner': json(partnerInput),
  'revenue.assignPartnerDriver': json(partnerDriverInput),
  'cases.sendCaseMessage': json(caseMessageInput),
  'cases.assignCase': json(caseAssignInput),
  'cases.addCaseNote': json(caseNoteInput),
  'planner-admin.reportAllergen': json(allergenReportInput),
  'planner-admin.reviewAllergenReport': json(allergenReviewInput),
  'cart.updateLine': json(cartUpdateInput),
  'cart.checkout': json(cartCheckoutInput),
  'planner.readText': json(planReadInput),
  'planner.saveDietProfile': json(dietProfileInput),
  'planner.createPlan': json(planCreateInput),
  'planner.updatePlan': json(planUpdateInput),
  'planner.addItem': json(planItemInput),
  'planner.updateItem': json(planItemUpdateInput),
  'planner.addMeal': json(planMealInput),
  'market-operations.saveCategory': json(categoryInput),
  'market-operations.savePolicies': json(policyInput),
  'market-operations.saveSellerDetails': json(sellerDetailsInput),
  'market-operations.saveDriverDetails': json(driverDetailsInput),
  'market-operations.saveWaypoint': json(waypointInput),
  'market-operations.savePath': json(pathInput),
  'delivery-operations.saveTariff': json(tariffInput),
  'discovery-operations.savePreferences': json(discoveryPreferenceInput),
  'returns-operations.create': json(returnJourneyInput),
  'parcels.create': json(parcelInput),
  'parcels.quote': json(parcelQuoteInput),
  'voice.signal': json(voiceSignalInput),
  'regions.saveRegion': json(regionInput),
  'shopping.create': json(shoppingInput),
  'local-status.publish': json(publishStatusInput),
  'status-boost.quote': json(boostInput),
  'status-boost.create': json(
    boostInput.and(z.object({ expected_fee_kobo: z.number().int().min(0) })),
  ),
  'shopping.quote': json(shoppingQuoteInput),
  'marketplace.applyAsSeller': json(sellerSchema),
  'marketplace.createListing': json(listingSchema),
  'marketplace.updateListing': json(listingSchema.partial()),
  'wallet.startFunding': json(fundingInput),
  'support.resolveDispute': json(resolveDisputeInput),
};
const queries: Record<string, z.ZodObject<any>> = {
  'geography.search': searchInput,
  'shopping.nearbyRiders': nearbyRiderInput,
  'local-status.feed': statusAreaInput,
  'local-status.event': statusAreaInput,
  'local-status.report': statusAreaInput,
};

/** Named response schemas (contracts/responses.ts) become components.schemas and are $ref'd. */
const schemaUri = (id: string) => `#/components/schemas/${id}`;
function namedSchemas() {
  const out = z.toJSONSchema(z.globalRegistry, {
    io: 'output',
    uri: schemaUri,
    unrepresentable: 'any',
  });
  const schemas: Record<string, Record<string, unknown>> = {};
  for (const [id, schema] of Object.entries(out.schemas)) {
    const { $schema: _drop, id: _id, ...rest } = schema as Record<string, unknown>;
    schemas[id] = rest;
  }
  return schemas;
}
function responseSchema(
  schema: z.ZodType,
  definitions: Record<string, unknown>,
  prefix: string,
): Record<string, unknown> {
  const id = (schema.meta() as { id?: string } | undefined)?.id;
  if (id) return { $ref: schemaUri(id) };
  if (schema instanceof z.ZodArray)
    return {
      type: 'array',
      items: responseSchema(schema.element as z.ZodType, definitions, prefix),
    };
  if (schema instanceof z.ZodNullable)
    return {
      anyOf: [responseSchema(schema.unwrap() as z.ZodType, definitions, prefix), { type: 'null' }],
    };
  const result = json(schema, 'output');
  const defs = (result.$defs || {}) as Record<string, unknown>;
  delete result.$defs;
  // JSON Schema's local definitions must live at the OpenAPI document root. Otherwise
  // #/$defs references inside a response point at a nonexistent document-level $defs.
  const relocate = (value: any): any => {
    if (Array.isArray(value)) return value.map(relocate);
    if (!value || typeof value !== 'object') return value;
    return Object.fromEntries(
      Object.entries(value).map(([key, child]) => [
        key,
        key === '$ref' && typeof child === 'string' && child.startsWith('#/$defs/')
          ? schemaUri(`${prefix}.${child.slice('#/$defs/'.length)}`)
          : relocate(child),
      ]),
    );
  };
  for (const [id, definition] of Object.entries(defs))
    definitions[`${prefix}.${id}`] = relocate(definition);
  return relocate(result);
}

const statusFor = (r: Route) =>
  ['register', 'login', 'forgotPassword'].includes(r.handler) && r.tag === 'auth'
    ? '202'
    : ['uploadPhoto', 'uploadEvidence', 'uploadDocument', 'uploadReceipt', 'uploadVideo'].includes(
          r.handler,
        )
      ? '201'
      : '200';

export function buildOpenApi() {
  const idempotent = idempotentHandlers();
  const paths: Record<string, Record<string, unknown>> = {};
  const definitions: Record<string, unknown> = {};
  for (const r of routes()) {
    const key = `${r.tag}.${r.handler}`;
    const path = r.path.replace(/:(\w+)/g, '{$1}');
    const parameters: unknown[] = [...r.path.matchAll(/:(\w+)/g)].map((m) => ({
      name: m[1],
      in: 'path',
      required: true,
      schema: { type: 'string' },
    }));
    if (idempotent.has(key)) parameters.push({ $ref: '#/components/parameters/IdempotencyKey' });
    const query = queries[key];
    if (query)
      for (const [name, field] of Object.entries(query.shape))
        parameters.push({ name, in: 'query', required: false, schema: json(field as z.ZodType) });
    const op: Record<string, unknown> = {
      operationId: key,
      tags: [r.tag],
      ...(parameters.length ? { parameters } : {}),
      ...(isPublic(r) ? { security: [] } : {}),
      responses: {
        [statusFor(r)]: {
          description: 'Success',
          content:
            r.handler === 'paymentReturnPage'
              ? { 'text/html': {} }
              : {
                  'application/json': responses[key]
                    ? { schema: responseSchema(responses[key], definitions, key) }
                    : {},
                },
        },
        default: { $ref: '#/components/responses/Error' },
      },
    };
    if (['post', 'put', 'patch'].includes(r.method)) {
      const upload = [
        'uploadPhoto',
        'uploadEvidence',
        'uploadDocument',
        'uploadReceipt',
        'uploadVideo',
      ].includes(r.handler);
      op.requestBody = upload
        ? {
            required: true,
            content: {
              'multipart/form-data': {
                schema: {
                  type: 'object',
                  properties: {
                    [r.handler === 'uploadPhoto'
                      ? 'image'
                      : r.handler === 'uploadVideo'
                        ? 'video'
                        : 'file']: {
                      type: 'string',
                      format: 'binary',
                    },
                  },
                },
              },
            },
          }
        : {
            required: Boolean(bodies[key]),
            content: {
              'application/json': {
                schema: bodies[key] ?? { type: 'object', additionalProperties: true },
              },
            },
          };
    }
    (paths[path] ??= {})[r.method] = op;
  }
  return {
    openapi: '3.1.0',
    info: {
      title: 'Ahia API',
      version: '1.0.0',
      description:
        'Generated from apps/api/src by `npm run openapi`. Amounts are integers in kobo. Writes that change money, orders or accounts require an Idempotency-Key; retries with the same key replay the first response.',
    },
    servers: [{ url: 'http://localhost:4000' }],
    security: [{ bearerAuth: [] }],
    paths,
    components: {
      securitySchemes: { bearerAuth: { type: 'http', scheme: 'bearer' } },
      parameters: {
        IdempotencyKey: {
          name: 'Idempotency-Key',
          in: 'header',
          required: true,
          schema: { type: 'string', minLength: 8, maxLength: 150 },
        },
      },
      schemas: {
        ...namedSchemas(),
        ...definitions,
        Error: {
          type: 'object',
          required: ['error'],
          properties: {
            error: {
              type: 'object',
              required: ['code', 'message'],
              properties: {
                code: {
                  type: 'string',
                  examples: ['VALIDATION_ERROR', 'NOT_FOUND', 'RATE_LIMITED'],
                },
                message: { type: 'string' },
                requestId: { type: 'string' },
              },
            },
          },
        },
      },
      responses: {
        Error: {
          description: 'Error with a machine-readable code',
          content: { 'application/json': { schema: { $ref: '#/components/schemas/Error' } } },
        },
      },
    },
  };
}

export const specPath = join(root, 'openapi.json');
export const render = () => `${JSON.stringify(buildOpenApi(), null, 2)}\n`;

if (process.argv[1] && resolve(process.argv[1]) === fileURLToPath(import.meta.url)) {
  if (process.argv.includes('--check')) {
    if (readFileSync(specPath, 'utf8') !== render()) {
      console.error('openapi.json is out of date. Run `npm run openapi -w @ahia/api`.');
      process.exit(1);
    }
    console.log('openapi.json is up to date.');
  } else {
    writeFileSync(specPath, render());
    console.log(`Wrote ${specPath}`);
  }
}
